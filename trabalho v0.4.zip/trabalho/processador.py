# -*- coding: utf-8 -*-
"""
Spyder Editor

Este é um arquivo de script temporário.
"""
operacoes = {'soma':'0000', 'sub':'0001', 'mult':'0010','div':'0011','load':'0100','0101':'store'}

reg_a=0
reg_b=0
reg_c=0


def eleva(x,y):
    return (x**y)

def gravar(pos, valor):
    arqM = open('memoria.txt', 'r+')
    mem2 = arqM.readlines()
    if(pos>len(mem2)):
        for i in range(len(mem2), pos+1):
            mem2.append('\n')
    mem2[pos] = str(valor)+'\n'
    arqM.close()
    arqM = open('memoria.txt', 'w+')
    arqM.writelines(mem2)
    arqM.close() 
    
def execute(tipo):
    
    if(tipo=='0101'):
        global reg_a,reg_b
        gravar(reg_a,reg_b)
    return
    
def find_data(instr, tipo):
    if(tipo=='0101'):
        global reg_a,reg_b
        reg_a=0
        reg_b=0
        for i in range(0,6):
            reg_a = reg_a + (eleva(2,(5-i)) * (int(instr[1][i]))) #converte binario decimal
            reg_b = reg_b + (eleva(2,(5-i)) * (int(instr[2][i])))
            print(reg_b)
        
    return
    
def get_instr_type(instr):
    return instr[0]
    
    
    
arqI = open('instru.txt','r')
texto = arqI.readlines()

instr = {}
instr_type=''


for pc in texto:

    arqM = open('memoria.txt', 'r+')
    mem = arqM.readlines()    
    
    instr = pc.split(' ') # Divide a linha de instrução em operação e as  duas variaveis
    instr_type = get_instr_type(instr)
    find_data(instr,instr_type)
    execute(instr_type)
    
    '''if(instr[0]=='0000'): #soma
        pos1=0
        pos2=0
        pos3=0
        for i in range(0,16):
            pos1 = pos1 + (eleva(2,(15-i)) * (int(instr[1][i]))) #converte binario decimal
            pos2 = pos2 + (eleva(2,(15-i)) * (int(instr[2][i])))
            pos3 = pos3 + (eleva(2,(15-i)) * (int(instr[3][i])))
            
        result = float(mem[pos2]) + float(mem[pos3]) 
        print(result)
        gravar(pos1,result)
        
        
    elif(instr[0]=='0001'):
        #print(mem[1])
        pos1=0
        pos2=0
        pos3=0
        for i in range(0,16):
            pos1 = pos1 + (eleva(2,(15-i)) * (int(instr[1][i])))
            pos2 = pos2 + (eleva(2,(15-i)) * (int(instr[2][i])))
            pos3 = pos3 + (eleva(2,(15-i)) * (int(instr[3][i])))
              
        result = float(mem[pos2]) - float(mem[pos3]) 
        print(result)
        gravar(pos1,result)
        
    elif(instr[0]=='0010'):
        pos1=0
        pos2=0
        pos3=0
        for i in range(0,16):
            pos1 = pos1 + (eleva(2,(15-i)) * (int(instr[1][i])))
            pos2 = pos2 + (eleva(2,(15-i)) * (int(instr[2][i])))
            pos3 = pos3 + (eleva(2,(15-i)) * (int(instr[3][i])))
        
        result = float(mem[pos2]) * float(mem[pos3])
        gravar(pos1,result)
        print result

    elif(instr[0]=='0011'):
        pos1=0
        pos2=0
        pos3=0
        for i in range(0,16):
            pos1 = pos1 + (eleva(2,(15-i)) * (int(instr[1][i])))
            pos2 = pos2 + (eleva(2,(15-i)) * (int(instr[2][i])))
            pos3 = pos3 + (eleva(2,(15-i)) * (int(instr[3][i])))
            
        result = float(mem[pos2]) / float(mem[pos3])
        print ("%.2f" % result)
        gravar(pos1,result)
        
    elif(instr[0]=='0100'):
        pos1=0
        pos2=0
        for i in range(0,16):
            pos1 = pos1 + (eleva(2,(15-i)) * (int(instr[1][i])))
            pos2 = pos2 + (eleva(2,(15-i)) * (int(instr[2][i])))
        arqM.close()
        gravar(pos1,pos2)'''
     
arqI.close()


#teste = '123456'
#arqM.write(teste)
